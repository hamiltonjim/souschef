create view units(id, name, type, in_base, abbrev, intl, alt_abbrev) as
SELECT volumes.id,
       volumes.name,
       'VOLUME'::text AS type,
       volumes.in_ml  AS in_base,
       volumes.abbrev,
       volumes.intl,
       volumes.alt_abbrev
FROM volumes
UNION
SELECT weights.id,
       weights.name,
       'WEIGHT'::text   AS type,
       weights.in_grams AS in_base,
       weights.abbrev,
       weights.intl,
       weights.alt_abbrev
FROM weights;

alter table units
    owner to postgres;

