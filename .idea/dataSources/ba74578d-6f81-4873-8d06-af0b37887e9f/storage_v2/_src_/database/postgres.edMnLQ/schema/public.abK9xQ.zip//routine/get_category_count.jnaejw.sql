create function get_category_count(include_deleted boolean)
    returns TABLE(category text, cnt bigint)
    language plpgsql
as
$$
begin
    if include_deleted then
        return query
            select c.name, count(r.id)
            from recipes r
                     join categories c on c.id = r.category_id
            group by c.name
            order by c.name;
    else
        return query
            select c.name, count(r.id)
            from recipes r
                     join categories c on c.id = r.category_id
            where r.deleted is not true
            group by c.name
            order by c.name;
    end if;
end;
$$;

alter function get_category_count(boolean) owner to postgres;

